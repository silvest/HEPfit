/* 
 * Copyright (C) 2012 HEPfit Collaboration
 *
 *
 * For the licensing terms see doc/COPYING.
 */

#include "Mw.h"
#include "StandardModel.h"

double Mw::computeThValue()
{
    return SM.Mw();
}

